from __future__ import annotations

from dataclasses import asdict, dataclass, field
import re
import time
from typing import Dict, List, Optional

from .config import WonderBotConfig
from .diagnostics import collect_runtime_diagnostics
from .event_codec import EventCodec, SegmentEvent
from .ganglion import Ganglion
from .llm_backends import create_backend
from .memory import MemoryStore
from .replay import ReplayLogger
from .resonance import ResonanceField
from .sensors import SensorHub, SensorObservation, build_sensor_hub
from .tts import build_speaker


@dataclass(slots=True)
class AgentTurn:
    stimulus: str
    response: Optional[str]
    resonance: float
    tick: int
    recalled: List[str]
    spontaneous: bool
    backend: str
    source: str = "user"
    salience: float = 0.0
    mode: str = "observe"
    inhibition_reason: str = ""
    backend_metadata: Dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


@dataclass(slots=True)
class FocusEntry:
    text: str
    source: str
    salience: float
    tick: int
    created_at_ms: int

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


@dataclass(slots=True)
class FocusState:
    mode: str = "observe"
    active_focus: str = ""
    goal_anchor: str = ""
    last_updated_ms: int = 0
    recent: List[FocusEntry] = field(default_factory=list)

    def to_dict(self) -> Dict[str, object]:
        return {
            "mode": self.mode,
            "active_focus": self.active_focus,
            "goal_anchor": self.goal_anchor,
            "last_updated_ms": self.last_updated_ms,
            "recent": [entry.to_dict() for entry in self.recent],
        }


WonderBotConfigAlias = WonderBotConfig


class WonderBot:
    def __init__(self, config: WonderBotConfig, sensor_hub: SensorHub | None = None) -> None:
        self.config = config
        self.codec = EventCodec(
            dim=config.codec.dim,
            ngram=config.codec.ngram,
            window_chars=config.codec.window_chars,
            min_segment_chars=config.codec.min_segment_chars,
            cosine_drop=config.codec.cosine_drop,
            lowercase=config.codec.lowercase,
            nfkc=config.codec.nfkc,
        )
        self.memory = MemoryStore(
            codec=self.codec,
            path=config.memory.path,
            max_active_items=config.memory.max_active_items,
            protect_identity=config.memory.protect_identity,
            importance_threshold=config.memory.importance_threshold,
            min_novelty=config.memory.min_novelty,
        )
        self.ganglion = Ganglion(
            height=config.ganglion.height,
            width=config.ganglion.width,
            channels=config.ganglion.channels,
            bleed=config.ganglion.bleed,
        )
        self.resonance = ResonanceField(
            sigma=config.resonance.sigma,
            tau=config.resonance.tau,
            alpha=config.resonance.alpha,
            prime_count=config.resonance.prime_count,
        )
        self.backend = create_backend(config=config.backend, codec=self.codec)
        self.sensor_hub = sensor_hub if sensor_hub is not None else build_sensor_hub(config)
        self.replay = ReplayLogger(
            path=config.logging.path,
            enabled=config.logging.enabled,
            flush_each_write=config.logging.flush_each_write,
        )
        self.speaker = build_speaker(config.tts)
        self.voice_enabled = config.tts.enabled and self.speaker.status().available
        self.last_turn: Optional[AgentTurn] = None
        self.focus_state = FocusState(last_updated_ms=_now_ms())
        self._idle_counter = 0
        self._last_response_ms = 0
        self._last_spontaneous_ms = 0
        self._last_sensor_response_ms = 0
        self._last_source_response_ms: Dict[str, int] = {}
        self._last_stimulus_seen_ms: Dict[str, int] = {}
        self._log_runtime_startup()

    def observe(self, stimulus: str, source: str = "user", explicit: bool = True) -> AgentTurn:
        return self._observe_common(stimulus=stimulus, source=source, explicit=explicit, source_salience=0.0, metadata=None)

    def observe_sensor(self, observation: SensorObservation) -> AgentTurn:
        return self._observe_common(
            stimulus=observation.text,
            source=observation.source,
            explicit=False,
            source_salience=observation.salience,
            metadata={**observation.metadata, "sensor": True, "salience": observation.salience},
        )

    def poll_sensors(self) -> List[AgentTurn]:
        turns: List[AgentTurn] = []
        for observation in self.sensor_hub.poll():
            self.replay.log(
                "sensor_observation",
                {
                    "source": observation.source,
                    "text": observation.text,
                    "salience": observation.salience,
                    "metadata": observation.metadata,
                    "tick": self.ganglion.t,
                },
            )
            if observation.salience < self.config.live.sensor_memory_threshold:
                self.replay.log(
                    "sensor_dropped",
                    {
                        "source": observation.source,
                        "salience": observation.salience,
                        "threshold": self.config.live.sensor_memory_threshold,
                        "text": observation.text,
                    },
                )
                continue
            turn = self.observe_sensor(observation)
            turns.append(turn)
        return turns

    def idle_tick(self, count: int = 1) -> List[AgentTurn]:
        turns: List[AgentTurn] = []
        for _ in range(max(1, count)):
            self.ganglion.tick()
            sensor_turns = self.poll_sensors() if self.config.live.enabled else []
            turns.extend(sensor_turns)
            self._idle_counter += 1
            if self._idle_counter >= self.config.agent.spontaneous_interval:
                now = _now_ms()
                if now - self._last_spontaneous_ms < int(self.config.stability.spontaneous_cooldown_seconds * 1000):
                    self.replay.log(
                        "spontaneous_suppressed",
                        {
                            "reason": "spontaneous cooldown active",
                            "tick": self.ganglion.t,
                        },
                    )
                    self._idle_counter = 0
                    continue
                memories = self.memory.top_memories(self.config.agent.max_context_memories)
                self.focus_state.mode = "reflect"
                result = self.backend.generate(stimulus="", memories=memories, style=self.config.agent.response_style, spontaneous=True)
                if result.text.strip():
                    text = result.text.strip()
                    self._store_memory(text, source="assistant", metadata={"spontaneous": True, **result.metadata})
                    self._note_response(source="assistant", stimulus="", spontaneous=True)
                    self._update_focus(text=text, source="assistant", salience=0.0, explicit=False)
                    turn = AgentTurn(
                        stimulus="",
                        response=text,
                        resonance=0.0,
                        tick=self.ganglion.t,
                        recalled=[memory.text for memory in memories],
                        spontaneous=True,
                        backend=result.backend_name,
                        source="assistant",
                        salience=0.0,
                        mode="reflect",
                        backend_metadata=result.metadata,
                    )
                    turns.append(turn)
                    self.last_turn = turn
                    self._emit_voice(turn)
                    self.replay.log("spontaneous_response", turn.to_dict())
                self._idle_counter = 0
        return turns

    def save(self) -> None:
        self.memory.save()
        self.replay.log("save", {"memory_path": self.config.memory.path, "tick": self.ganglion.t})

    def close(self) -> None:
        self.sensor_hub.close()
        self.save()
        self.speaker.close()
        self.replay.close()

    def diagnostics(self) -> Dict[str, object]:
        sensor_statuses = [asdict(status) for status in self.sensor_hub.status()]
        return collect_runtime_diagnostics(
            config=self.config,
            backend_name=getattr(self.backend, "name", type(self.backend).__name__),
            sensor_statuses=sensor_statuses,
            speaker_status=asdict(self.speaker.status()),
            replay_status=asdict(self.replay.status()),
            focus_state=self.focus_state.to_dict(),
            memory_stats=self.memory.stats(),
        )

    def set_voice_enabled(self, enabled: bool) -> bool:
        available = self.speaker.status().available
        self.voice_enabled = bool(enabled and available)
        self.replay.log("voice_toggle", {"enabled": self.voice_enabled, "available": available})
        return self.voice_enabled

    def state_summary(self) -> Dict[str, object]:
        return {
            "tick": self.ganglion.t,
            "ganglion": self.ganglion.state_summary().to_dict(),
            "memory": self.memory.stats(),
            "focus": self.focus_state.to_dict(),
            "voice": {
                "enabled": self.voice_enabled,
                "status": asdict(self.speaker.status()),
            },
            "replay": asdict(self.replay.status()),
            "sensors": [asdict(status) for status in self.sensor_hub.status()],
            "last_turn": self.last_turn.to_dict() if self.last_turn else None,
        }

    def _observe_common(
        self,
        stimulus: str,
        source: str,
        explicit: bool,
        source_salience: float,
        metadata: Optional[Dict[str, object]],
    ) -> AgentTurn:
        stimulus = stimulus.strip()
        now = _now_ms()
        events = self.codec.analyze_text(stimulus)
        if stimulus:
            self._store_memory(stimulus, source=source, metadata={"explicit": explicit, **(metadata or {})})
        self._update_focus(text=stimulus, source=source, salience=source_salience, explicit=explicit)
        resonance_value = self._ingest_events(events)
        drive = max(resonance_value, min(1.0, source_salience * self.config.live.sensor_reaction_gain))
        recalled_items = (
            self.memory.search(stimulus, k=self.config.agent.max_context_memories)
            if stimulus
            else self.memory.top_memories(self.config.agent.max_context_memories)
        )
        recalled = [item.text for item in recalled_items]
        should_answer = explicit or drive >= self.config.live.sensor_reaction_threshold or self.resonance.should_react(
            drive,
            self.config.agent.reaction_threshold,
            explicit=explicit,
        )
        response = None
        inhibition_reason = ""
        backend_name = self.backend.name if hasattr(self.backend, "name") else type(self.backend).__name__
        backend_metadata: Dict[str, object] = {}
        self.focus_state.mode = "think" if should_answer else "observe"
        if should_answer:
            allowed, inhibition_reason = self._response_allowed(
                source=source,
                explicit=explicit,
                source_salience=source_salience,
                stimulus=stimulus,
                now_ms=now,
            )
            if allowed:
                result = self.backend.generate(
                    stimulus=stimulus,
                    memories=recalled_items,
                    style=self.config.agent.response_style,
                    spontaneous=False,
                )
                response = result.text.strip()
                backend_name = result.backend_name
                backend_metadata = dict(result.metadata)
                if response:
                    self._store_memory(response, source="assistant", metadata={"stimulus": stimulus, "source": source, **backend_metadata})
                    self._note_response(source=source, stimulus=stimulus, spontaneous=False)
                    self.focus_state.mode = "respond"
            else:
                self.focus_state.mode = "observe"
                self.replay.log(
                    "response_suppressed",
                    {
                        "source": source,
                        "stimulus": stimulus,
                        "reason": inhibition_reason,
                        "salience": source_salience,
                        "tick": self.ganglion.t,
                    },
                )
        if source == "user":
            self.ganglion.tick()
            self._idle_counter = 0
        turn = AgentTurn(
            stimulus=stimulus,
            response=response,
            resonance=round(drive, 6),
            tick=self.ganglion.t,
            recalled=recalled,
            spontaneous=False,
            backend=backend_name,
            source=source,
            salience=round(source_salience, 6),
            mode=self.focus_state.mode,
            inhibition_reason=inhibition_reason,
            backend_metadata=backend_metadata,
        )
        self.last_turn = turn
        self.replay.log("turn", turn.to_dict())
        self._emit_voice(turn)
        return turn

    def _store_memory(self, text: str, source: str, metadata: Dict[str, object]) -> None:
        item = self.memory.add(text, source=source, metadata=metadata)
        self.replay.log(
            "memory_write",
            {
                "id": item.id,
                "source": source,
                "text": item.text,
                "priority": item.priority,
                "importance": item.importance,
                "novelty": item.novelty,
                "metadata": metadata,
            },
        )

    def _note_response(self, source: str, stimulus: str, spontaneous: bool) -> None:
        now = _now_ms()
        self._last_response_ms = now
        self._last_source_response_ms[source] = now
        if not spontaneous and source != "user":
            self._last_sensor_response_ms = now
        if spontaneous:
            self._last_spontaneous_ms = now
        normalized = _normalize_key(stimulus)
        if normalized:
            self._last_stimulus_seen_ms[normalized] = now

    def _update_focus(self, text: str, source: str, salience: float, explicit: bool) -> None:
        focus_text = _extract_focus(text)
        if not focus_text:
            return
        now = _now_ms()
        self.focus_state.last_updated_ms = now
        if explicit and source == "user":
            self.focus_state.goal_anchor = focus_text
        self.focus_state.active_focus = focus_text
        self.focus_state.recent.append(
            FocusEntry(text=focus_text, source=source, salience=round(max(salience, 0.05 if explicit else salience), 6), tick=self.ganglion.t, created_at_ms=now)
        )
        self._trim_focus_entries(now)

    def _trim_focus_entries(self, now_ms: int) -> None:
        decay_ms = int(self.config.agent.focus_decay_seconds * 1000)
        kept = [entry for entry in self.focus_state.recent if now_ms - entry.created_at_ms <= decay_ms]
        self.focus_state.recent = kept[-self.config.agent.focus_max_items :]

    def _response_allowed(self, source: str, explicit: bool, source_salience: float, stimulus: str, now_ms: int) -> tuple[bool, str]:
        if explicit:
            return True, ""
        if source_salience < self.config.stability.minimum_response_salience:
            return False, "salience stayed below the minimum response threshold"
        if now_ms - self._last_sensor_response_ms < int(self.config.stability.sensor_response_cooldown_seconds * 1000):
            return False, "global sensor response cooldown active"
        last_for_source = self._last_source_response_ms.get(source, 0)
        if now_ms - last_for_source < int(self.config.stability.same_source_cooldown_seconds * 1000):
            return False, f"{source} cooldown active"
        normalized = _normalize_key(stimulus)
        if normalized:
            last_seen = self._last_stimulus_seen_ms.get(normalized, 0)
            if now_ms - last_seen < int(self.config.stability.repeated_stimulus_cooldown_seconds * 1000):
                return False, "repeated stimulus cooldown active"
        return True, ""

    def _emit_voice(self, turn: AgentTurn) -> None:
        if not self.voice_enabled or not turn.response:
            return
        if turn.spontaneous and not self.config.tts.speak_spontaneous:
            return
        if turn.source in {"camera", "microphone"} and not self.config.tts.speak_sensor_responses:
            return
        if turn.source == "user" and not self.config.tts.speak_user_responses:
            return
        self.speaker.say(turn.response)
        self.replay.log("voice_output", {"text": turn.response, "source": turn.source, "spontaneous": turn.spontaneous})

    def _ingest_events(self, events: List[SegmentEvent]) -> float:
        if not events:
            return 0.0
        for event in events:
            self.ganglion.write_signature(event.signature)
        return self.resonance.score_many([event.signature for event in events], tick=self.ganglion.t)

    def _log_runtime_startup(self) -> None:
        self.replay.log(
            "startup",
            {
                "backend": getattr(self.backend, "name", type(self.backend).__name__),
                "diagnostics": self.diagnostics(),
            },
        )


_STOPWORDS = {
    'a', 'an', 'and', 'are', 'as', 'at', 'be', 'been', 'being', 'but', 'by', 'do', 'does', 'for', 'from', 'get', 'got', 'had', 'has', 'have', 'how', 'i', 'if', 'in', 'into', 'is', 'it', 'its', 'just', 'like', 'more', 'my', 'now', 'of', 'on', 'or', 'our', 'so', 'stuff', 'that', 'the', 'their', 'them', 'then', 'there', 'these', 'they', 'this', 'to', 'up', 'use', 'was', 'we', 'what', 'when', 'where', 'which', 'with', 'would', 'you', 'your', 'fren'
}


def _extract_focus(text: str) -> str:
    raw = ' '.join(text.strip().split())
    if not raw:
        return ''
    lowered = raw.lower()
    patterns = [
        r'(?:about|regarding|focused on|centered on|working on|for)\s+([^,.!?]{4,90})',
        r'(?:design|build|make|wire|stabilize|improve|tune)\s+([^,.!?]{4,90})',
    ]
    for pattern in patterns:
        match = re.search(pattern, lowered)
        if match:
            phrase = match.group(1).strip(' .,:;!?')
            if phrase:
                return phrase[:96]
    quoted = re.findall(r'"([^"]{3,96})"', raw)
    if quoted:
        return quoted[0].strip()
    tokens = re.findall(r"[A-Za-z0-9][A-Za-z0-9_\-']+", raw)
    content = [token for token in tokens if token.lower() not in _STOPWORDS and len(token) > 2]
    if not content:
        return raw[:96]
    return ' '.join(content[:6])[:96]


def _normalize_key(text: str) -> str:
    return ' '.join(text.lower().split())


def _now_ms() -> int:
    return int(time.time() * 1000)


WonderBotConfig = WonderBotConfigAlias
