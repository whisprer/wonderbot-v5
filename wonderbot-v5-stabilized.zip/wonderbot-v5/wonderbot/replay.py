from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import time
from typing import Any


@dataclass(slots=True)
class ReplayStatus:
    enabled: bool
    path: str
    detail: str


class ReplayLogger:
    def __init__(self, path: str, enabled: bool = True, flush_each_write: bool = True) -> None:
        self.enabled = enabled
        self.path = Path(path)
        self.flush_each_write = flush_each_write
        self._handle = None
        self._detail = "logging disabled"
        if self.enabled:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._handle = self.path.open("a", encoding="utf-8")
            self._detail = f"writing replay events to {self.path}"

    def log(self, kind: str, payload: dict[str, Any]) -> None:
        if not self.enabled or self._handle is None:
            return
        record = {
            "ts_ms": int(time.time() * 1000),
            "kind": kind,
            "payload": payload,
        }
        self._handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        if self.flush_each_write:
            self._handle.flush()

    def status(self) -> ReplayStatus:
        return ReplayStatus(enabled=self.enabled, path=str(self.path), detail=self._detail)

    def close(self) -> None:
        if self._handle is not None:
            self._handle.flush()
            self._handle.close()
            self._handle = None
