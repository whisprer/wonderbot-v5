# wonderbot-v6

A clean consolidation base for the archived LLM/agent experiments, now extended through **phase 6 memory consolidation and reflection**.

This repo is deliberately **not** another fragile wrapper around a standard tokenizer pretending to be tokenizerless.
Instead it separates the system into clear layers:

1. **Event codec** — resonant segmentation + lossless byte encoding + feature signatures.
2. **Memory** — append-only, priority-ranked, searchable, non-destructive.
3. **Ganglion** — a clocked CA bus that gives the agent a continuously evolving internal substrate.
4. **LLM backend** — swappable. The default backend is a no-dependency local LVTC-style backend with a grounded path plus a guarded imagination branch; optional HuggingFace support can be enabled later.
5. **Live perception** — optional camera and microphone adapters, plus optional caption/STT enrichers.
6. **Stability shell** — focus state, anti-chatter cooldowns, replay logging, diagnostics, and optional TTS.
7. **Journal layer** — summaries, extracted tasks, beliefs, unfinished threads, and replay-based reflection.

That split is the point: the old projects drifted because the “new tokenizer” was treated as if it could be dropped into a pretrained LM without retraining the representational contract. This base stops doing that.

## What phase 6 adds

- **Journal store** in `state/journal.json`.
- **Consolidation engine** that turns recent episodic memories into:
  - summaries
  - tasks
  - beliefs/preferences
  - unfinished threads
- **Replay-based reflection** that comments on imagination use, suppressions, and live-sensor influence.
- **Auto-consolidation** after a configurable number of explicit user turns.
- New CLI commands:
  - `/consolidate`
  - `/reflect`
  - `/journal [kind] [n]`
  - `/tasks`
  - `/beliefs`
  - `/threads`

## What this repo does now

- Runs immediately with **no third-party dependencies**.
- Uses a **local LVTC-style controlled-imagination backend** by default.
- Supports an interactive, always-on-ish CLI agent that forms and searches memory continuously.
- Uses a **replacement tokenizer architecture where it is actually sound**: segmentation, salience, memory, and internal event coding.
- Keeps the LLM backend abstract so you can stay lightweight now, plug in HF later, or replace the backend entirely with a future native event-stream model.
- Supports **optional live camera and microphone sensing**.
- Supports **optional image captioning and speech transcription enrichment** behind the same sensor contract.
- Supports **optional voice output** without making voice a hard dependency.
- Supports **durable journaled consolidation**, so the system can accumulate structured takeaways instead of only raw turns.

## What this repo does not pretend to do

- It does **not** claim that a pretrained LM has become tokenizerless.
- It does **not** require camera, mic, Whisper, BLIP, or TTS just to boot.
- It does **not** destroy memory entries when consolidating.
- It does **not** force imagination into every turn.

## Quick start

```bash
py -3.11 -m wonderbot.cli
```

Or after install:

```bash
py -3.11 -m pip install -e .
wonderbot
```

## Live sensing

Sensor-only live mode:

```bash
py -3.11 -m pip install -e .[live]
py -3.11 -m wonderbot.cli --live --camera --microphone
```

Phase 4/5/6 live mode with captioning, STT, and optional TTS:

```bash
py -3.11 -m pip install -e .[live-full,voice,dev]
py -3.11 -m wonderbot.cli --live --camera --microphone --caption --stt --tts --diagnostics
```

## Useful commands

- `/sensors` — show adapter and voice availability
- `/sense` — poll sensors once immediately
- `/watch 20` — run 20 live polling ticks with the configured interval
- `/memory 10` — inspect what actually got stored
- `/focus` — inspect the current active focus and goal anchor
- `/diagnostics` — dump runtime diagnostics
- `/voice on` / `/voice off` — enable or disable speaking for the current run
- `/consolidate` — synthesize a session summary + tasks + beliefs + threads
- `/reflect` — run the replay-based reflection pass only
- `/journal summary 5` — inspect the latest summary entries
- `/tasks`, `/beliefs`, `/threads` — inspect structured takeaways

## Replay log

Every significant runtime event is appended as JSONL to `state/replay.jsonl`, including:

- startup diagnostics
- sensor observations
- dropped sensor events
- memory writes
- response suppressions
- generated turns
- spontaneous responses
- voice output events
- journal summaries/tasks/beliefs/threads/reflections

That gives you a clean basis for later replay, tuning, and behavior audits.

## Optional HuggingFace backend

```bash
py -3.11 -m pip install -e .[hf]
py -3.11 -m wonderbot.cli --backend hf --hf-model distilgpt2
```

Note: the HF backend still uses its own tokenizer internally. That is intentional. The **agent contract** is event-coded text and memory; the backend is only one possible renderer.

## Repo layout

```text
wonderbot/
  agent.py
  cli.py
  config.py
  consolidation.py
  diagnostics.py
  event_codec.py
  ganglion.py
  journal.py
  llm_backends.py
  memory.py
  perception.py
  replay.py
  resonance.py
  tts.py
  sensors/
configs/
  default.toml
docs/
  ARCHITECTURE.md
  CONSOLIDATION_NOTES.md
  LEGACY_MAP.md
scripts/
  seed_from_legacy.py
tests/
```
