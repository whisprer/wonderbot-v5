from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

try:
    import tomllib  # type: ignore[attr-defined]
except ModuleNotFoundError:  # pragma: no cover - Python <3.11 fallback
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass(slots=True)
class CodecConfig:
    dim: int = 192
    ngram: int = 3
    window_chars: int = 16
    min_segment_chars: int = 4
    cosine_drop: float = 0.14
    lowercase: bool = False
    nfkc: bool = True


@dataclass(slots=True)
class MemoryConfig:
    path: str = 'state/memory.json'
    max_active_items: int = 2000
    protect_identity: bool = True
    importance_threshold: float = 0.36
    min_novelty: float = 0.08


@dataclass(slots=True)
class JournalConfig:
    path: str = 'state/journal.json'


@dataclass(slots=True)
class ConsolidationConfig:
    auto_enabled: bool = True
    auto_every_explicit_turns: int = 3
    summary_min_items: int = 4
    summary_window_items: int = 12
    max_summary_sentences: int = 3
    task_limit: int = 4
    belief_limit: int = 4
    thread_limit: int = 4


@dataclass(slots=True)
class GanglionConfig:
    height: int = 8
    width: int = 8
    channels: int = 8
    bleed: float = 0.03


@dataclass(slots=True)
class ResonanceConfig:
    sigma: float = 0.5
    tau: float = 14.134725
    alpha: float = 1.2
    prime_count: int = 32


@dataclass(slots=True)
class BackendConfig:
    kind: str = 'lvtc'
    hf_model: str = 'distilgpt2'
    max_new_tokens: int = 120
    temperature: float = 0.8
    delta_scale: float = 0.24
    creative_depth: int = 1
    anchor_pullback: float = 0.72
    novelty_threshold: float = 0.10
    drift_threshold: float = 0.58
    repetition_threshold: float = 0.34
    latency_budget_ms: int = 30


@dataclass(slots=True)
class AgentConfig:
    name: str = 'wonderbot'
    response_style: str = 'warm, concise, reflective, technical when useful'
    reaction_threshold: float = 0.18
    spontaneous_interval: int = 5
    max_context_memories: int = 6
    focus_max_items: int = 6
    focus_decay_seconds: float = 180.0


@dataclass(slots=True)
class LiveConfig:
    enabled: bool = False
    poll_interval_ms: int = 350
    sensor_memory_threshold: float = 0.10
    sensor_reaction_threshold: float = 0.18
    sensor_reaction_gain: float = 1.15


@dataclass(slots=True)
class CameraConfig:
    enabled: bool = False
    index: int = 0
    width: int = 320
    height: int = 240
    motion_threshold: float = 0.08
    brightness_threshold: float = 0.05
    min_salience: float = 0.12


@dataclass(slots=True)
class MicrophoneConfig:
    enabled: bool = False
    sample_rate: int = 16000
    channels: int = 1
    window_seconds: float = 0.35
    rms_threshold: float = 0.03
    peak_threshold: float = 0.12
    min_salience: float = 0.10


@dataclass(slots=True)
class CaptionConfig:
    enabled: bool = False
    model: str = 'Salesforce/blip-image-captioning-base'
    max_new_tokens: int = 24
    interval_seconds: float = 3.0
    salience_threshold: float = 0.22
    min_chars: int = 12


@dataclass(slots=True)
class SpeechConfig:
    enabled: bool = False
    model: str = 'openai/whisper-tiny.en'
    language: str = 'en'
    salience_threshold: float = 0.22
    min_chars: int = 4
    cooldown_seconds: float = 0.75


@dataclass(slots=True)
class StabilityConfig:
    sensor_response_cooldown_seconds: float = 2.0
    spontaneous_cooldown_seconds: float = 6.0
    repeated_stimulus_cooldown_seconds: float = 3.5
    same_source_cooldown_seconds: float = 1.25
    minimum_response_salience: float = 0.18


@dataclass(slots=True)
class LoggingConfig:
    enabled: bool = True
    path: str = 'state/replay.jsonl'
    flush_each_write: bool = True


@dataclass(slots=True)
class TTSConfig:
    enabled: bool = False
    rate: int = 185
    volume: float = 0.9
    voice_contains: str = ''
    speak_user_responses: bool = True
    speak_sensor_responses: bool = False
    speak_spontaneous: bool = True


@dataclass(slots=True)
class WonderBotConfig:
    agent: AgentConfig
    codec: CodecConfig
    memory: MemoryConfig
    journal: JournalConfig
    consolidation: ConsolidationConfig
    ganglion: GanglionConfig
    resonance: ResonanceConfig
    backend: BackendConfig
    live: LiveConfig
    camera: CameraConfig
    microphone: MicrophoneConfig
    caption: CaptionConfig
    speech: SpeechConfig
    stability: StabilityConfig
    logging: LoggingConfig
    tts: TTSConfig

    @classmethod
    def load(cls, path: str | Path) -> 'WonderBotConfig':
        data = _read_toml(path)
        return cls(
            agent=AgentConfig(**data.get('agent', {})),
            codec=CodecConfig(**data.get('codec', {})),
            memory=MemoryConfig(**data.get('memory', {})),
            journal=JournalConfig(**data.get('journal', {})),
            consolidation=ConsolidationConfig(**data.get('consolidation', {})),
            ganglion=GanglionConfig(**data.get('ganglion', {})),
            resonance=ResonanceConfig(**data.get('resonance', {})),
            backend=BackendConfig(**data.get('backend', {})),
            live=LiveConfig(**data.get('live', {})),
            camera=CameraConfig(**data.get('camera', {})),
            microphone=MicrophoneConfig(**data.get('microphone', {})),
            caption=CaptionConfig(**data.get('caption', {})),
            speech=SpeechConfig(**data.get('speech', {})),
            stability=StabilityConfig(**data.get('stability', {})),
            logging=LoggingConfig(**data.get('logging', {})),
            tts=TTSConfig(**data.get('tts', {})),
        )


def _read_toml(path: str | Path) -> Dict[str, Any]:
    with open(path, 'rb') as handle:
        return tomllib.load(handle)
